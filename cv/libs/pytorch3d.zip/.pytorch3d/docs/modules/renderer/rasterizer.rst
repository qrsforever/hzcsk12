rasterizer
===========================

.. automodule:: pytorch3d.renderer.mesh.rasterize_meshes
    :members:
    :undoc-members:
    
.. automodule:: pytorch3d.renderer.mesh.rasterizer
    :members:
    :undoc-members: