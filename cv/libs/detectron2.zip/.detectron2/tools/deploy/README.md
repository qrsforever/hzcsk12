
This directory contains:

1. A script that converts a detectron2 model to caffe2 format.

2. An example that loads a Mask R-CNN model in caffe2 format and runs inference.

See [tutorial](https://detectron2.readthedocs.io/tutorials/deployment.html)
for their usage.
