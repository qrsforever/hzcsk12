.. role:: hidden
    :class: hidden-section

apex.optimizers
===================================

.. automodule:: apex.optimizers
.. currentmodule:: apex.optimizers

.. FusedAdam
   ----------

.. autoclass:: FusedAdam
    :members:

.. autoclass:: FusedLAMB
    :members:

.. autoclass:: FusedNovoGrad
    :members:

.. autoclass:: FusedSGD
    :members:
