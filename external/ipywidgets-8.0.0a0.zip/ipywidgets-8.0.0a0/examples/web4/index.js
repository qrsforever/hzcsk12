require('@jupyter-widgets/html-manager/dist/embed');
