// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.

export const JUPYTER_WIDGETS_VERSION = '2.0.0';

export const PROTOCOL_VERSION = '2.0.0';
