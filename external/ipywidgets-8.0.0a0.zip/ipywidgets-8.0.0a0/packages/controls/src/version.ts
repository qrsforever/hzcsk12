// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.

/**
 * The version of the Jupyter controls widget attribute spec that this package
 * implements.
 */
export const JUPYTER_CONTROLS_VERSION = '2.0.0';
