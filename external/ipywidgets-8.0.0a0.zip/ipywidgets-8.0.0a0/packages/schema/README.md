Jupyter Widgets Schema
======================

JSON schema for the json serialization of Jupyter Interactive Widgets.

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)
