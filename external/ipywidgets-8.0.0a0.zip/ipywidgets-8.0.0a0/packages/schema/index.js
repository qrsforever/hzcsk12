module.exports = {
  v1: {
    state: require('./v1/state.schema.json'),
    view: require('./v1/view.schema.json')
  },
  v2: {
    state: require('./v2/state.schema.json'),
    view: require('./v2/view.schema.json')
  }
};
