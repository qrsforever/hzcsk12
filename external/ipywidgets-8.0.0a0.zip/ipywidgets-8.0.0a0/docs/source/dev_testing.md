Testing
=======

To run the Python tests:

    pytest --cov=ipywidgets ipywidgets

To run the Javascript tests in each package directory:

    yarn test

This will run the test suite using `karma` with 'debug' level logging.
